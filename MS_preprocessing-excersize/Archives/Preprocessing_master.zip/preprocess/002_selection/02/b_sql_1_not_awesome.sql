SELECT *
FROM work.reserve_tb
WHERE checkout_date BETWEEN '2016-10-13' AND '2016-10-14'
